package com.training.educationsystem.controller;

public @interface Valid {

}
